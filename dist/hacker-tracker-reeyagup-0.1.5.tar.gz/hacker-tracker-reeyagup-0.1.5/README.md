# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

A README file, either in plaintext or markdown (UTF-8) should be included. The README should have, at
a minimum, the following information:
- A description of the project
- Package name for PIP installation
- Run executable command and, if application, initialization command
- Link to the repository for the project (e.g., GitHub) [Note: if private, you must add instructors]
- For mobile projects, a link to the application package (APK)

Packages used: 
    tkinter,
    tkcalendar,
    nltk,
    spacy,
    wordnet,
    spacytextblob,
    pandas,
    mathplotlib